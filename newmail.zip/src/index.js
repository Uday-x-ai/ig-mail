const TelegramBot = require("node-telegram-bot-api");
const { botToken } = require("./config");
require("./data/db");
const { registerCommandHandlers } = require("./bot/commands");
const { startMailPoller } = require("./services/mailPoller");

if (!botToken) {
  throw new Error("BOT_TOKEN is missing in environment variables.");
}

const bot = new TelegramBot(botToken, { polling: true });

registerCommandHandlers(bot);
startMailPoller(bot);

console.log("TempMail bot is running.");
