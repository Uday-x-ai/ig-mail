const { pollIntervalMs } = require("../config");
const { listMailboxMessages } = require("./cpanelClient");
const { getRecipientsForEmail, saveReceivedMail } = require("./emailService");

function startMailPoller(bot) {
  let isRunning = false;

  setInterval(async () => {
    if (isRunning) {
      return;
    }
    isRunning = true;

    try {
      const messages = await listMailboxMessages();
      for (const msg of messages) {
        const recipients = getRecipientsForEmail(msg.to);
        if (!recipients.length) {
          continue;
        }

        saveReceivedMail(msg.to, msg);

        const text = [
          "New email received",
          `To: ${msg.to}`,
          `From: ${msg.from || "unknown"}`,
          `Subject: ${msg.subject || "(no subject)"}`,
          "",
          msg.body || "(empty body)",
        ].join("\n");

        for (const chatId of recipients) {
          await bot.sendMessage(chatId, text);
        }
      }
    } catch (err) {
      console.error("Mail poller error:", err.message);
    } finally {
      isRunning = false;
    }
  }, pollIntervalMs);
}

module.exports = {
  startMailPoller,
};
