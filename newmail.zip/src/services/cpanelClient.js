const axios = require("axios");
const { cpanel } = require("../config");

function ensureConfigured() {
  if (!cpanel.baseUrl || !cpanel.username || !cpanel.apiToken || !cpanel.domain) {
    throw new Error("cPanel is not fully configured in environment variables.");
  }
}

function client() {
  ensureConfigured();
  return axios.create({
    baseURL: cpanel.baseUrl.replace(/\/+$/, ""),
    headers: {
      Authorization: `cpanel ${cpanel.username}:${cpanel.apiToken}`,
      Accept: "application/json",
      "User-Agent": "TempMailBot/0.1",
    },
    timeout: 15000,
  });
}

function formatCpanelError(operation, err) {
  const status = err?.response?.status;
  const body = err?.response?.data;
  const bodyText =
    typeof body === "string"
      ? body
      : body?.errors?.join("; ") || body?.error || body?.message || "";

  if (status === 403) {
    return `${operation} failed (403 Access denied). Check CPANEL_BASE_URL (port 2083), API token permissions, and server firewall/IP allowlist.`;
  }

  if (status) {
    return `${operation} failed (${status})${bodyText ? `: ${bodyText}` : ""}`;
  }

  return `${operation} failed: ${err.message}`;
}

async function createEmailAccount(localPart, password) {
  const http = client();
  let response;
  try {
    response = await http.get("/execute/Email/add_pop", {
      params: {
        email: localPart,
        domain: cpanel.domain,
        password,
        quota: 100,
      },
    });
  } catch (err) {
    throw new Error(formatCpanelError("Create email", err));
  }

  if (!response.data?.status) {
    throw new Error(response.data?.errors?.join("; ") || "Create email failed");
  }

  return `${localPart}@${cpanel.domain}`;
}

async function deleteEmailAccount(fullEmail) {
  const [localPart, domain] = fullEmail.split("@");
  const http = client();
  let response;
  try {
    response = await http.get("/execute/Email/delete_pop", {
      params: {
        email: localPart,
        domain,
      },
    });
  } catch (err) {
    throw new Error(formatCpanelError("Delete email", err));
  }

  if (!response.data?.status) {
    throw new Error(response.data?.errors?.join("; ") || "Delete email failed");
  }
}

async function createForwarder(fullEmail, forwardToAddress) {
  const [localPart, domain] = fullEmail.split("@");
  const [destLocalPart, destDomain] = forwardToAddress.split("@");
  const http = client();
  let response;
  try {
    response = await http.get("/execute/Email/add_forwarder", {
      params: {
        domain,
        email: localPart,
        fwdopt: "fwd",
        fwdemail: `${destLocalPart}@${destDomain}`,
      },
    });
  } catch (err) {
    throw new Error(formatCpanelError("Create forwarder", err));
  }

  if (!response.data?.status) {
    throw new Error(response.data?.errors?.join("; ") || "Create forwarder failed");
  }
}

async function listMailboxMessages() {
  return [];
}

module.exports = {
  createEmailAccount,
  deleteEmailAccount,
  createForwarder,
  listMailboxMessages,
};
