const crypto = require("crypto");
const db = require("../data/db");
const { economy, cpanel } = require("../config");
const { createEmailAccount, deleteEmailAccount } = require("./cpanelClient");

const generateCooldownByUser = new Map();

function randomLocalPart() {
  return `tmp${crypto.randomBytes(4).toString("hex")}`;
}

function canGenerateNow(userId) {
  const now = Date.now();
  const last = generateCooldownByUser.get(userId) || 0;
  if (now - last < 5000) {
    return false;
  }
  generateCooldownByUser.set(userId, now);
  return true;
}

async function generateEmailForUser(user) {
  if (!canGenerateNow(user.id)) {
    throw new Error("Too many requests. Please wait a few seconds.");
  }

  if (user.balance < economy.generateCost) {
    throw new Error("Insufficient points. Use /redeem or /addbal.");
  }

  const localPart = randomLocalPart();
  const randomPassword = crypto.randomBytes(12).toString("base64url");
  const fullEmail = cpanel.domain ? `${localPart}@${cpanel.domain}` : `${localPart}@example.com`;

  try {
    if (cpanel.domain) {
      await createEmailAccount(localPart, randomPassword);
    }
  } catch (err) {
    if (!cpanel.strictMode) {
      console.warn("cPanel create failed; continuing due to CPANEL_STRICT_MODE=false:", err.message);
    } else {
      throw new Error(`Email creation failed: ${err.message}`);
    }
  }

  const tx = db.transaction(() => {
    db.prepare(
      "INSERT INTO emails (email, owner_id, status) VALUES (?, ?, 'active')"
    ).run(fullEmail, user.id);
    db.prepare("UPDATE users SET balance = balance - ? WHERE id = ?").run(economy.generateCost, user.id);
    db.prepare(
      "INSERT INTO transactions (user_id, type, amount, description) VALUES (?, 'email_generate', ?, ?)"
    ).run(user.id, -economy.generateCost, `Generated ${fullEmail}`);
  });
  tx();

  return fullEmail;
}

function listOwnedEmails(userId) {
  return db
    .prepare("SELECT id, email, status, created_at FROM emails WHERE owner_id = ? ORDER BY id ASC")
    .all(userId);
}

function getEmailByAddress(email) {
  return db.prepare("SELECT * FROM emails WHERE email = ?").get(email.toLowerCase());
}

function getAccessibleEmailForUser(emailAddress, userId) {
  const email = getEmailByAddress(emailAddress);
  if (!email || email.status !== "active") {
    return null;
  }

  if (email.owner_id === userId) {
    return email;
  }

  const shared = db
    .prepare("SELECT id FROM shared_access WHERE email_id = ? AND user_id = ?")
    .get(email.id, userId);

  return shared ? email : null;
}

function buildExternalId(message) {
  if (message?.messageId) {
    return String(message.messageId);
  }

  const raw = [
    message?.to || "",
    message?.from || "",
    message?.subject || "",
    message?.date || "",
    message?.body || "",
  ].join("|");

  return crypto.createHash("sha256").update(raw).digest("hex");
}

function saveReceivedMail(emailAddress, message) {
  const email = getEmailByAddress(emailAddress);
  if (!email || email.status !== "active") {
    return;
  }

  const externalId = buildExternalId(message);
  db.prepare(
    `INSERT OR IGNORE INTO received_mails
     (email_id, external_id, from_address, subject, body, received_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(
    email.id,
    externalId,
    message?.from || null,
    message?.subject || null,
    message?.body || null,
    message?.date || null
  );
}

function getReceivedMailsForUser(emailAddress, userId, limit = 10) {
  const email = getAccessibleEmailForUser(emailAddress, userId);
  if (!email) {
    throw new Error("Email not found or you do not have access.");
  }

  return db
    .prepare(
      `SELECT from_address, subject, body, received_at, created_at
       FROM received_mails
       WHERE email_id = ?
       ORDER BY id DESC
       LIMIT ?`
    )
    .all(email.id, limit);
}

function transferEmail(emailAddress, fromUserId, toUserId) {
  const email = getEmailByAddress(emailAddress);
  if (!email || email.status !== "active") {
    throw new Error("Email not found or not active.");
  }
  if (email.owner_id !== fromUserId) {
    throw new Error("You are not the owner of this email.");
  }

  db.prepare("UPDATE emails SET owner_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(toUserId, email.id);
  db.prepare("DELETE FROM shared_access WHERE email_id = ?").run(email.id);
}

function transferByIndex(fromUserId, index, toUserId) {
  const rows = listOwnedEmails(fromUserId).filter((r) => r.status === "active");
  const row = rows[index - 1];
  if (!row) {
    throw new Error("Invalid email index.");
  }
  transferEmail(row.email, fromUserId, toUserId);
  return row.email;
}

async function deleteEmail(emailAddress, userId) {
  const email = getEmailByAddress(emailAddress);
  if (!email || email.status !== "active") {
    throw new Error("Email not found or already deleted.");
  }
  if (email.owner_id !== userId) {
    throw new Error("You are not the owner of this email.");
  }

  try {
    if (cpanel.domain) {
      await deleteEmailAccount(emailAddress);
    }
  } catch (err) {
    if (!cpanel.strictMode) {
      console.warn("cPanel delete failed; continuing due to CPANEL_STRICT_MODE=false:", err.message);
    } else {
      throw new Error(`Email delete failed: ${err.message}`);
    }
  }

  db.prepare(
    "UPDATE emails SET status = 'deleted', owner_id = NULL, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).run(email.id);
  db.prepare("DELETE FROM shared_access WHERE email_id = ?").run(email.id);
}

function acceptDeletedEmail(emailAddress, userId) {
  const email = getEmailByAddress(emailAddress);
  if (!email || email.status !== "deleted") {
    throw new Error("Email is not available for reclaim.");
  }

  db.prepare(
    "UPDATE emails SET status = 'active', owner_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).run(userId, email.id);
}

function shareEmail(emailAddress, ownerId, targetUserId) {
  const email = getEmailByAddress(emailAddress);
  if (!email || email.status !== "active") {
    throw new Error("Email not found or inactive.");
  }
  if (email.owner_id !== ownerId) {
    throw new Error("Only owner can share this email.");
  }

  db.prepare("INSERT OR IGNORE INTO shared_access (email_id, user_id) VALUES (?, ?)").run(email.id, targetUserId);
}

function stopShareEmail(emailAddress, ownerId) {
  const email = getEmailByAddress(emailAddress);
  if (!email) {
    throw new Error("Email not found.");
  }
  if (email.owner_id !== ownerId) {
    throw new Error("Only owner can stop share access.");
  }

  db.prepare("DELETE FROM shared_access WHERE email_id = ?").run(email.id);
}

function getRecipientsForEmail(emailAddress) {
  const email = getEmailByAddress(emailAddress);
  if (!email || email.status !== "active") {
    return [];
  }

  const owner = db.prepare("SELECT telegram_id FROM users WHERE id = ?").get(email.owner_id);
  const shared = db
    .prepare(
      `SELECT u.telegram_id
       FROM shared_access sa
       JOIN users u ON u.id = sa.user_id
       WHERE sa.email_id = ?`
    )
    .all(email.id);

  const recipients = [];
  if (owner?.telegram_id) {
    recipients.push(owner.telegram_id);
  }
  for (const row of shared) {
    recipients.push(row.telegram_id);
  }
  return [...new Set(recipients)];
}

module.exports = {
  generateEmailForUser,
  listOwnedEmails,
  saveReceivedMail,
  getReceivedMailsForUser,
  transferEmail,
  transferByIndex,
  deleteEmail,
  acceptDeletedEmail,
  shareEmail,
  stopShareEmail,
  getRecipientsForEmail,
};
